﻿"""Framework template for Section 1 (Investigation Objectives & Case Profile)."""

from __future__ import annotations

from typing import Any, Dict

from .section_framework_base import (
    CommunicationContract,
    FactGraphContract,
    PersistenceContract,
    SectionFramework,
    StageDefinition,
)


class Section1Framework(SectionFramework):
    SECTION_ID = "section_1_profile"
    MAX_RERUNS = 2
    STAGES = (
        StageDefinition(
            name="acquire",
            description="Load intake docs, register evidence, verify file integrity.",
            checkpoint="s1_profile_acquire",
            guardrails=("order_lock", "async_queue", "persistence_snapshot"),
        ),
        StageDefinition(
            name="extract",
            description="Run strongest-first extraction for IDs, contracts, manifests.",
            checkpoint="s1_profile_extract",
            guardrails=("confidence_threshold", "fallback_logging"),
        ),
        StageDefinition(
            name="normalize",
            description="Apply parsing maps, toolkit rules (alias dedupe, continuity).",
            checkpoint="s1_profile_normalized",
            guardrails=("schema_validation", "fact_graph_sync"),
        ),
        StageDefinition(
            name="validate",
            description="Enforce Cochran/North Star, legal compliance; capture QA issues.",
            checkpoint="s1_profile_validated",
            guardrails=("continuity_checks", "manual_queue_routes"),
        ),
        StageDefinition(
            name="publish",
            description="Publish payload to gateway, emit dependency signals, record approvals.",
            checkpoint="section_1_profile_completed",
            guardrails=("durable_persistence", "signal_emission", "immutability"),
        ),
        StageDefinition(
            name="monitor",
            description="Handle revision requests while enforcing rerun guardrails.",
            checkpoint="s1_profile_revision_processed",
            guardrails=("max_reruns", "revision_depth_cap", "fact_graph_consistency"),
        ),
    )

    COMMUNICATION = CommunicationContract(
        prepare_signal="case_bundle.initialized",
        input_channels=(
            "intake_bundle",
            "extracted_metadata",
            "toolkit_cache",
            "manual_overrides",
        ),
        output_signal="section_1_profile.completed",
        revision_signal="case_metadata_revision",
    )

    ORDER = OrderContract(\n        execution_after=('section_cp', 'section_toc'),\n        export_after=(),\n        export_priority=10,\n    )\n\n    def load_inputs(self) -> Dict[str, Any]:
        """Template hook for retrieving inputs from the gateway."""
        raise NotImplementedError

    def build_payload(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Template hook for constructing the structured payload."""
        raise NotImplementedError

    def publish(self, payload: Dict[str, Any]) -> None:
        """Template hook for persisting state and emitting signals."""
        raise NotImplementedError






