﻿"""Framework template for Section 3 (Surveillance Reports / Daily Logs)."""

from __future__ import annotations

from typing import Any, Dict

from .section_framework_base import (
    CommunicationContract,
    FactGraphContract,
    PersistenceContract,
    SectionFramework,
    StageDefinition,
)


class Section3Framework(SectionFramework):
    SECTION_ID = "section_3"
    MAX_RERUNS = 3
    STAGES = (
        StageDefinition(
            name="intake",
            description="Pull inputs, verify Section 1/2 hashes, load media references.",
            checkpoint="s3_intake_logged",
            guardrails=("order_lock", "async_queue", "persistence_snapshot"),
        ),
        StageDefinition(
            name="extract",
            description="Process field logs (OCR), ingest GPS/EXIF, transcribe audio (Whisper).",
            checkpoint="s3_extraction_complete",
            guardrails=("confidence_threshold", "fallback_logging", "durable_media_index"),
        ),
        StageDefinition(
            name="correlate",
            description="Align observations with planning timelines and media assets; build structured log entries.",
            checkpoint="s3_correlated",
            guardrails=("timeline_alignment", "fact_graph_sync"),
        ),
        StageDefinition(
            name="validate",
            description="Run QA (continuity checks, subject alignment, timestamp integrity, Cochran compliance).",
            checkpoint="s3_validated",
            guardrails=("continuity_checks", "manual_queue_routes"),
        ),
        StageDefinition(
            name="publish",
            description="Persist log manifest, emit surveillance-ready signal, record approvals.",
            checkpoint="section_3_completed",
            guardrails=("durable_persistence", "signal_emission", "immutability"),
        ),
        StageDefinition(
            name="monitor",
            description="Handle revision requests from planning or evidence updates within rerun guardrails.",
            checkpoint="s3_revision_processed",
            guardrails=("max_reruns", "revision_depth_cap", "fact_graph_consistency"),
        ),
    )

    COMMUNICATION = CommunicationContract(
        prepare_signal="planning_ready",
        input_channels=(
            "case_metadata",
            "subject_manifest",
            "planning_manifest",
            "media_index",
            "voice_transcripts",
            "toolkit_results",
        ),
        output_signal="surveillance_ready",
        revision_signal="surveillance_revision",
    )

    ORDER = OrderContract(\n        execution_after=('',),\n        export_after=('',),\n        export_priority=30,\n    )\n\n    def load_inputs(self) -> Dict[str, Any]:
        """Template hook for retrieving inputs from the gateway."""
        raise NotImplementedError

    def build_payload(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Template hook for constructing the structured payload."""
        raise NotImplementedError

    def publish(self, payload: Dict[str, Any]) -> None:
        """Template hook for persisting state and emitting signals."""
        raise NotImplementedError






