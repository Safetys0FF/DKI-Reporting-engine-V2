#!/usr/bin/env python3
"""
Narrative Assembler - Implementation from dki_scale_model.py
Assembles structured data into narrative text for reports
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class NarrativeAssembler:
    """Narrative assembly system for converting structured data to text"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.logger = logging.getLogger(__name__)
        
        # Narrative templates for different sections
        self.narrative_templates = {
            'section_1': {
                'header': "INVESTIGATION OBJECTIVES & CASE PROFILE",
                'template': "This investigation was initiated on {date} regarding {subject}. The scope includes {scope}.",
                'required_fields': ['date', 'subject', 'scope']
            },
            'section_2': {
                'header': "PRE-SURVEILLANCE / CASE PREPARATION",
                'template': "Pre-surveillance activities were conducted on {date} at {location}. Subject verification completed for {subject}.",
                'required_fields': ['date', 'location', 'subject']
            },
            'section_3': {
                'header': "SURVEILLANCE REPORTS / DAILY LOGS",
                'template': "Surveillance activities conducted on {date} at {location}. Subject {subject} was observed {activity}.",
                'required_fields': ['date', 'location', 'subject', 'activity']
            },
            'section_4': {
                'header': "REVIEW OF SURVEILLANCE SESSIONS",
                'template': "Review of surveillance session conducted on {date}. Key findings include {findings}.",
                'required_fields': ['date', 'findings']
            },
            'section_5': {
                'header': "SUPPORTING DOCUMENTS & RECORDS",
                'template': "Supporting documentation reviewed includes {documents}. Key information: {summary}.",
                'required_fields': ['documents', 'summary']
            },
            'section_6': {
                'header': "BILLING SUMMARY",
                'template': "Billing summary for case {case_id}. Total hours: {hours}, Mileage: {mileage}, Total cost: {total}.",
                'required_fields': ['case_id', 'hours', 'mileage', 'total']
            },
            'section_7': {
                'header': "CONCLUSION",
                'template': "Investigation concluded on {date}. Final findings: {findings}. Status: {status}.",
                'required_fields': ['date', 'findings', 'status']
            },
            'section_8': {
                'header': "PHOTO / EVIDENCE INDEX",
                'template': "Evidence index contains {count} items. Key evidence includes {evidence_summary}.",
                'required_fields': ['count', 'evidence_summary']
            },
            'section_9': {
                'header': "CERTIFICATION & DISCLAIMERS",
                'template': "Investigator {investigator} certifies the accuracy of this report. License: {license}.",
                'required_fields': ['investigator', 'license']
            }
        }
        
        # Style guidelines
        self.style_guidelines = {
            'tone': 'professional',
            'tense': 'past',
            'person': 'third',
            'max_sentence_length': 25,
            'avoid_words': ['maybe', 'possibly', 'might', 'could', 'seems'],
            'required_words': ['confirmed', 'verified', 'observed', 'documented']
        }
    
    def assemble(self, section_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Assemble narrative from structured data"""
        try:
            if section_id not in self.narrative_templates:
                return self._assemble_generic(section_id, data)
            
            template_info = self.narrative_templates[section_id]
            template = template_info['template']
            required_fields = template_info['required_fields']
            
            # Check for required fields
            missing_fields = []
            for field in required_fields:
                if field not in data or not data[field]:
                    missing_fields.append(field)
            
            if missing_fields:
                return {
                    'success': False,
                    'narrative': '',
                    'error': f"Missing required fields: {', '.join(missing_fields)}",
                    'missing_fields': missing_fields
                }
            
            # Format the template with data
            try:
                narrative = template.format(**data)
            except KeyError as e:
                return {
                    'success': False,
                    'narrative': '',
                    'error': f"Template formatting error: {str(e)}",
                    'missing_fields': [str(e)]
                }
            
            # Apply style guidelines
            narrative = self._apply_style_guidelines(narrative)
            
            # Generate structured output
            result = {
                'success': True,
                'narrative': narrative,
                'header': template_info['header'],
                'section_id': section_id,
                'template_used': template,
                'data_fields': list(data.keys()),
                'style_applied': True,
                'timestamp': datetime.now().isoformat()
            }
            
            return result
            
        except Exception as e:
            self.logger.error(f"Narrative assembly failed for {section_id}: {e}")
            return {
                'success': False,
                'narrative': '',
                'error': str(e),
                'section_id': section_id
            }
    
    def _assemble_generic(self, section_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Assemble narrative for sections without specific templates"""
        try:
            # Extract key information
            narrative_parts = []
            
            # Add timestamp if available
            if 'timestamp' in data:
                narrative_parts.append(f"Activity recorded on {data['timestamp']}.")
            
            # Add subject information
            if 'subject' in data:
                narrative_parts.append(f"Subject: {data['subject']}.")
            
            # Add location information
            if 'location' in data:
                narrative_parts.append(f"Location: {data['location']}.")
            
            # Add activity information
            if 'activity' in data:
                narrative_parts.append(f"Activity: {data['activity']}.")
            
            # Add findings
            if 'findings' in data:
                narrative_parts.append(f"Findings: {data['findings']}.")
            
            # Combine into narrative
            narrative = " ".join(narrative_parts)
            
            if not narrative.strip():
                narrative = f"Section {section_id} data processed. No specific narrative generated."
            
            # Apply style guidelines
            narrative = self._apply_style_guidelines(narrative)
            
            return {
                'success': True,
                'narrative': narrative,
                'header': f"SECTION {section_id.upper()}",
                'section_id': section_id,
                'template_used': 'generic',
                'data_fields': list(data.keys()),
                'style_applied': True,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Generic narrative assembly failed for {section_id}: {e}")
            return {
                'success': False,
                'narrative': '',
                'error': str(e),
                'section_id': section_id
            }
    
    def _apply_style_guidelines(self, narrative: str) -> str:
        """Apply style guidelines to narrative text"""
        try:
            # Convert to professional tone
            narrative = narrative.strip()
            
            # Ensure proper capitalization
            if narrative and not narrative[0].isupper():
                narrative = narrative[0].upper() + narrative[1:]
            
            # Ensure proper ending punctuation
            if narrative and not narrative[-1] in '.!?':
                narrative += '.'
            
            # Replace avoid words
            for word in self.style_guidelines['avoid_words']:
                narrative = narrative.replace(word, 'confirmed')
            
            # Split long sentences
            sentences = narrative.split('. ')
            processed_sentences = []
            
            for sentence in sentences:
                if len(sentence.split()) > self.style_guidelines['max_sentence_length']:
                    # Split long sentence
                    words = sentence.split()
                    mid_point = len(words) // 2
                    part1 = ' '.join(words[:mid_point])
                    part2 = ' '.join(words[mid_point:])
                    processed_sentences.extend([part1, part2])
                else:
                    processed_sentences.append(sentence)
            
            narrative = '. '.join(processed_sentences)
            
            return narrative
            
        except Exception as e:
            self.logger.warning(f"Style guidelines application failed: {e}")
            return narrative
    
    def assemble_section_3_specific(self, data: Dict[str, Any]) -> str:
        """Specific assembly for Section 3 surveillance data"""
        try:
            subject = data.get('subject', '[Unknown Subject]')
            location = data.get('location', '[Unknown Location]')
            blocks = data.get('content', [])
            
            output = []
            for block in blocks:
                start_time = block.get('start', 'Unknown time')
                action = block.get('action', 'Unknown activity')
                output.append(
                    f"On record, subject {subject} was observed to {action.lower()} at {location} around {start_time}."
                )
            
            return "\n".join(output)
            
        except Exception as e:
            self.logger.error(f"Section 3 specific assembly failed: {e}")
            return "[No narrative template for this section]"
    
    def validate_narrative(self, narrative: str) -> Dict[str, Any]:
        """Validate narrative against style guidelines"""
        validation_result = {
            'valid': True,
            'issues': [],
            'suggestions': []
        }
        
        try:
            # Check for avoid words
            for word in self.style_guidelines['avoid_words']:
                if word in narrative.lower():
                    validation_result['issues'].append(f"Avoid word found: {word}")
                    validation_result['valid'] = False
            
            # Check sentence length
            sentences = narrative.split('. ')
            for i, sentence in enumerate(sentences):
                if len(sentence.split()) > self.style_guidelines['max_sentence_length']:
                    validation_result['issues'].append(f"Sentence {i+1} too long: {len(sentence.split())} words")
                    validation_result['suggestions'].append(f"Consider splitting sentence {i+1}")
            
            # Check for required words
            narrative_lower = narrative.lower()
            for word in self.style_guidelines['required_words']:
                if word not in narrative_lower:
                    validation_result['suggestions'].append(f"Consider using '{word}' for more definitive language")
            
            return validation_result
            
        except Exception as e:
            self.logger.error(f"Narrative validation failed: {e}")
            return {
                'valid': False,
                'issues': [f"Validation error: {str(e)}"],
                'suggestions': []
            }
    
    def update_template(self, section_id: str, template: str, required_fields: List[str]):
        """Update narrative template for a section"""
        self.narrative_templates[section_id] = {
            'template': template,
            'required_fields': required_fields
        }
        self.logger.info(f"Updated narrative template for {section_id}")
    
    def get_available_templates(self) -> Dict[str, Any]:
        """Get all available narrative templates"""
        return {
            'templates': self.narrative_templates,
            'style_guidelines': self.style_guidelines,
            'total_templates': len(self.narrative_templates)
        }

