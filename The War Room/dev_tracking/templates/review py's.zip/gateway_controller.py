#!/usr/bin/env python3
"""
Gateway Controller - Core Gateway orchestration following dki_scale_model.py
Implements the actual architecture: Gateway owns master evidence index, sections are ecosystems
"""

import os
import uuid
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional, Set

logger = logging.getLogger(__name__)

class GatewayController:
    """Core Gateway Controller - owns master evidence index and mediates section communication"""
    
    def __init__(self):
        self.master_evidence_index = {}
        self.evidence_map = {}
        self.section_cache = {}
        self.completed_sections = set()
        self.logger = logging.getLogger(__name__)
        
        self.logger.info("Gateway Controller initialized")
    
    def register_file(self, file_path: str) -> Dict[str, Any]:
        """Register file in master evidence index"""
        # Simple classification logic from dki_scale_model.py
        name = os.path.basename(file_path).lower()
        
        if "lease" in name or "contract" in name:
            section = "section_5"
        elif name.endswith(".mp4") or "surveillance" in name:
            section = "section_3"
        elif name.endswith(".jpg") or name.endswith(".png"):
            section = "section_8"
        else:
            section = "unassigned"
        
        evidence_id = str(uuid.uuid4())
        
        record = {
            "filename": os.path.basename(file_path),
            "path": file_path,
            "assigned_section": section,
            "cross_links": [],
            "evidence_id": evidence_id
        }
        
        self.master_evidence_index[evidence_id] = record
        
        if section not in self.evidence_map:
            self.evidence_map[section] = []
        
        self.evidence_map[section].append(record)
        
        self.logger.info(f"🧾 Registered {file_path} to {section} as {evidence_id}")
        
        return {
            'success': True,
            'evidence_id': evidence_id,
            'section': section,
            'record': record
        }
    
    def get_evidence_for(self, section_id: str) -> List[Dict[str, Any]]:
        """Get evidence assigned to specific section"""
        return self.evidence_map.get(section_id, [])
    
    def add_cross_link(self, evidence_id: str, keyword: str):
        """Add cross-link to evidence"""
        if evidence_id in self.master_evidence_index:
            self.master_evidence_index[evidence_id]["cross_links"].append(keyword)
            self.logger.info(f"🔗 Added cross-link: {keyword} to {evidence_id}")
    
    def transfer_section_data(self, section_id: str, structured_section_data: Dict[str, Any]):
        """Section publishes structured data back to Gateway"""
        self.section_cache[section_id] = {
            "data": structured_section_data,
            "validated": False,
            "timestamp": datetime.now().isoformat(),
            "review_notes": []
        }
        self.logger.info(f"📡 Section data stored for {section_id}")
    
    def sign_off_section(self, section_id: str, by_user: str):
        """Sign off and validate section"""
        if section_id in self.section_cache:
            self.section_cache[section_id]["validated"] = True
            self.section_cache[section_id]["signed_by"] = by_user
            self.section_cache[section_id]["sign_time"] = datetime.now().isoformat()
            self.completed_sections.add(section_id)
            self.logger.info(f"✅ Section {section_id} validated and authorized by {by_user}")
    
    def is_section_complete(self, section_id: str) -> bool:
        """Check if section is complete"""
        return section_id in self.completed_sections
    
    def get_authorized_context(self) -> Dict[str, Any]:
        """Get authorized context from completed sections"""
        authorized = {}
        for sec_id in self.completed_sections:
            authorized[sec_id] = self.section_cache[sec_id]["data"]
        return authorized
    
    def assemble_for_report(self, section_id: str) -> Optional[Dict[str, Any]]:
        """Assemble section data for report generation"""
        entry = self.section_cache.get(section_id)
        if not entry:
            return None
        
        data = entry["data"]
        
        if section_id == "section_3":
            blocks = data.get("content", [])
            subject = data.get("subject", "[Unknown Subject]")
            location = data.get("location", "[Unknown Location]")
            narrative = "\n".join([
                f"At {b['start']} — {b['action']} at {location}" for b in blocks
            ])
            return {
                "header": f"Surveillance Summary: {subject}",
                "body": narrative,
                "meta": {
                    "tags": data.get("narrative_tags", []),
                    "priority": data.get("priority", "low"),
                    "validated": entry["validated"],
                    "signed_by": entry.get("signed_by"),
                    "sign_time": entry.get("sign_time")
                }
            }
        return None

