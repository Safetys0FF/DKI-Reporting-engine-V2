#!/usr/bin/env python3
"""
Evidence Classifier - Implementation from dki_scale_model.py
Classifies evidence files and assigns them to appropriate sections
"""

import os
import mimetypes
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path
import json

logger = logging.getLogger(__name__)

class EvidenceClassifier:
    """Evidence classification system for file routing"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.logger = logging.getLogger(__name__)
        
        # Classification rules based on dki_scale_model.py
        self.classification_rules = {
            # Contract and legal documents -> Section 5
            'contract_keywords': ['lease', 'contract', 'agreement', 'terms', 'legal'],
            'contract_section': 'section_5',
            
            # Surveillance and video -> Section 3
            'surveillance_keywords': ['surveillance', 'video', 'recording', 'camera', 'footage'],
            'surveillance_extensions': ['.mp4', '.mov', '.avi', '.mkv', '.wmv'],
            'surveillance_section': 'section_3',
            
            # Images and photos -> Section 8
            'image_extensions': ['.jpg', '.jpeg', '.png', '.tiff', '.tif', '.bmp', '.heic'],
            'image_section': 'section_8',
            
            # Audio files -> Section 3 (voice memos)
            'audio_extensions': ['.mp3', '.wav', '.m4a', '.aac', '.ogg'],
            'audio_section': 'section_3',
            
            # Documents and forms -> Section 5
            'document_extensions': ['.pdf', '.docx', '.doc', '.txt', '.rtf'],
            'document_section': 'section_5',
            
            # Spreadsheets and data -> Section 6 (billing)
            'spreadsheet_extensions': ['.xlsx', '.xls', '.csv'],
            'spreadsheet_section': 'section_6',
            
            # Default fallback
            'default_section': 'unassigned'
        }
        
        # Section priority mapping
        self.section_priorities = {
            'section_1': 1,  # Gateway - highest priority
            'section_2': 2,  # Pre-surveillance
            'section_3': 3,  # Surveillance logs
            'section_4': 4,  # Review of surveillance
            'section_5': 5,  # Supporting documents
            'section_6': 6,  # Billing
            'section_7': 7,  # Conclusion
            'section_8': 8,  # Photo/evidence index
            'section_9': 9,  # Certification
            'section_cp': 10, # Cover page
            'section_dp': 11, # Disclosure page
            'section_fr': 12, # Final assembly
            'unassigned': 99  # Lowest priority
        }
    
    def classify(self, file_path: str) -> Dict[str, Any]:
        """Classify a file and return section assignment with metadata"""
        try:
            file_name = os.path.basename(file_path).lower()
            file_ext = Path(file_path).suffix.lower()
            mime_type, _ = mimetypes.guess_type(file_path)
            
            # Initialize classification result
            classification = {
                'file_path': file_path,
                'file_name': file_name,
                'file_extension': file_ext,
                'mime_type': mime_type,
                'assigned_section': self.classification_rules['default_section'],
                'confidence': 0.0,
                'classification_reason': '',
                'priority': self.section_priorities[self.classification_rules['default_section']],
                'metadata': {}
            }
            
            # Rule 1: Contract keywords in filename
            if any(keyword in file_name for keyword in self.classification_rules['contract_keywords']):
                classification['assigned_section'] = self.classification_rules['contract_section']
                classification['confidence'] = 0.9
                classification['classification_reason'] = 'Contract keyword in filename'
                classification['priority'] = self.section_priorities[self.classification_rules['contract_section']]
                return classification
            
            # Rule 2: Surveillance keywords in filename
            if any(keyword in file_name for keyword in self.classification_rules['surveillance_keywords']):
                classification['assigned_section'] = self.classification_rules['surveillance_section']
                classification['confidence'] = 0.9
                classification['classification_reason'] = 'Surveillance keyword in filename'
                classification['priority'] = self.section_priorities[self.classification_rules['surveillance_section']]
                return classification
            
            # Rule 3: Video files -> Section 3
            if file_ext in self.classification_rules['surveillance_extensions']:
                classification['assigned_section'] = self.classification_rules['surveillance_section']
                classification['confidence'] = 0.8
                classification['classification_reason'] = 'Video file extension'
                classification['priority'] = self.section_priorities[self.classification_rules['surveillance_section']]
                return classification
            
            # Rule 4: Audio files -> Section 3
            if file_ext in self.classification_rules['audio_extensions']:
                classification['assigned_section'] = self.classification_rules['audio_section']
                classification['confidence'] = 0.8
                classification['classification_reason'] = 'Audio file extension'
                classification['priority'] = self.section_priorities[self.classification_rules['audio_section']]
                return classification
            
            # Rule 5: Images -> Section 8
            if file_ext in self.classification_rules['image_extensions']:
                classification['assigned_section'] = self.classification_rules['image_section']
                classification['confidence'] = 0.8
                classification['classification_reason'] = 'Image file extension'
                classification['priority'] = self.section_priorities[self.classification_rules['image_section']]
                return classification
            
            # Rule 6: Spreadsheets -> Section 6 (billing)
            if file_ext in self.classification_rules['spreadsheet_extensions']:
                classification['assigned_section'] = self.classification_rules['spreadsheet_section']
                classification['confidence'] = 0.8
                classification['classification_reason'] = 'Spreadsheet file extension'
                classification['priority'] = self.section_priorities[self.classification_rules['spreadsheet_section']]
                return classification
            
            # Rule 7: Documents -> Section 5
            if file_ext in self.classification_rules['document_extensions']:
                classification['assigned_section'] = self.classification_rules['document_section']
                classification['confidence'] = 0.7
                classification['classification_reason'] = 'Document file extension'
                classification['priority'] = self.section_priorities[self.classification_rules['document_section']]
                return classification
            
            # Default: Unassigned
            classification['classification_reason'] = 'No matching classification rules'
            classification['confidence'] = 0.0
            
            return classification
            
        except Exception as e:
            self.logger.error(f"Classification failed for {file_path}: {e}")
            return {
                'file_path': file_path,
                'assigned_section': 'unassigned',
                'confidence': 0.0,
                'classification_reason': f'Classification error: {str(e)}',
                'priority': 99
            }
    
    def classify_batch(self, file_paths: List[str]) -> Dict[str, Any]:
        """Classify multiple files and return organized results"""
        results = {
            'total_files': len(file_paths),
            'classifications': {},
            'section_counts': {},
            'unassigned_files': [],
            'processing_summary': {}
        }
        
        # Initialize section counts
        for section in self.section_priorities.keys():
            results['section_counts'][section] = 0
        
        # Classify each file
        for file_path in file_paths:
            classification = self.classify(file_path)
            results['classifications'][file_path] = classification
            
            # Update counts
            section = classification['assigned_section']
            results['section_counts'][section] += 1
            
            if section == 'unassigned':
                results['unassigned_files'].append(file_path)
        
        # Generate processing summary
        results['processing_summary'] = {
            'successfully_classified': results['total_files'] - len(results['unassigned_files']),
            'unassigned_count': len(results['unassigned_files']),
            'classification_rate': (results['total_files'] - len(results['unassigned_files'])) / results['total_files'] if results['total_files'] > 0 else 0
        }
        
        return results
    
    def get_section_files(self, classifications: Dict[str, Any], section: str) -> List[str]:
        """Get all files assigned to a specific section"""
        section_files = []
        for file_path, classification in classifications.items():
            if classification['assigned_section'] == section:
                section_files.append(file_path)
        return section_files
    
    def update_classification_rules(self, new_rules: Dict[str, Any]):
        """Update classification rules"""
        self.classification_rules.update(new_rules)
        self.logger.info("Classification rules updated")
    
    def get_classification_stats(self) -> Dict[str, Any]:
        """Get classification statistics and rules"""
        return {
            'rules': self.classification_rules,
            'section_priorities': self.section_priorities,
            'total_rules': len(self.classification_rules),
            'total_sections': len(self.section_priorities)
        }

