﻿# Section 1 / Gateway Engine - Structured Rebuild Roadmap (Draft)

## 1. Mission Statement
Provide the authoritative ingress/egress point for the DKI Engine. Section 1 must lock case identity, orchestrate tool execution, and broker evidence distribution so every downstream section operates on the same validated metadata.

### Information Reference Guide
- `F:\DKI-Report-Engine\Report Engine\Logic files\canvas logic for report`
- `F:\DKI-Report-Engine\Report Engine\Sections\section_readme`
- `F:\DKI-Report-Engine\Report Engine\Gateway`
- `F:\DKI-Report-Engine\Report Engine\Sections\section_engines`
- `F:\DKI-Report-Engine\Report Engine\Gateway\parsing maps`
- `F:\DKI-Report-Engine\Report Engine\Gateway\section_readme`
- `F:\DKI-Report-Engine\Report Engine\dev_tracking\templates`

### Boot-Up Sequences & Testing Procedures
- `F:\DKI-Report-Engine\Report Engine\Start Menu`

### Tool Sets & Engines
- `F:\DKI-Report-Engine\Report Engine\Plugins`
- `F:\DKI-Report-Engine\Report Engine\Processors`

## 2. Documentation Alignment & Enforcement
- **Authoritative references**
  - README: `Sections/section_readme/Section_1_README.md`
  - Engines/renderers: `Sections/section_engines/`, `Sections/section_renderers/`
  - Toolkit modules: `metadata_tool_v_5.py`, `cochran_match_tool.py`, `northstar_protocol_tool.py`
  - SOP/hand-off assets: `dev_tracking/templates/`, `CoreSystem/SOP.md`
- **Enforcement plan**
  - Map parsing rules directly into normalization/validation stages.
  - Keep README/SOP in sync with schema/workflow changes (doc version hash embedded in payload).
  - Automated schema/style tests prevent drift.

## 3. System Context
- **Ingress:** All case packages, uploads, and manual inputs flow through the gateway before any section runs.
- **Egress:** Finalized case metadata, approvals, and change deltas are redistributed from the gateway to sections, UI, and final assembly.
- **Scope:** Intake normalization, subject/contract validation, section staging, cross-section signaling, high-confidence narrative seeding.

## 4. Gateway Communication Contract
- `gateway.prepare_section(section_id)` – marks prerequisites satisfied via async queue.
- `gateway.get_section_inputs(section_id)` – returns structured slices (`case_metadata`, `intake_docs`, `toolkit_results`, `evidence_links`).
- `gateway.publish_section_result(section_id, payload)` – stores outputs with QA/provenance and persists them to disk.
- `gateway.subscribe(signal, callback)` – lets Section 1 react to downstream status changes.
- `gateway.emit(signal, context)` – broadcasts metadata revisions, using the shared fact graph for alignment.

## 5. Stage Checklist & Checkpoints
| Stage | Description | Inputs | Checkpoint |
|-------|-------------|--------|------------|
| Ingest | Parse intake bundle, classify artefacts, populate evidence index. | uploads, user profile, config | `case_ingest_complete` with import stats |
| Normalize | Run strongest-first extraction (Tesseract/Unstructured) for IDs, contracts, profiles. | evidence index entries | `case_metadata_ready` flag, toolkit normalization log |
| Validate | Execute toolkit continuity (North Star, Cochran) and compliance checks. | normalized metadata | `case_scope_validated`, QA flags stored |
| Publish | Push `section_1_payload` to gateway, trigger dependent sections. | validated payload | `section_1_completed` event |
| Monitor | Listen for downstream conflicts via async queue, rerunning within ``max_reruns`` limits and logging ``revision_depth``. | section state updates | `case_metadata_revision` queue, rerun instructions |

## 6. Guardrails & Failsafes
- **Schema enforcement:** Reject payloads missing required fields (`case_id`, `client_profile`, `subject_manifest`).
- **Confidence thresholds:** Halt progression if primary OCR confidence < threshold without successful fallback.
- **Resilient orchestration:** Commands flow through async queues; routing/state persistence lives outside the controller so restarts recover without data loss.
- **Change control:** Mutations post-publication require signed approvals; gateway keeps revision ledger.
- **Immutability enforcement:** Once a section is signed off its payload is frozen; reopen requests require authorization and create an archived version.
- **Revision controls:** Track ``revision_depth`` and enforce ``max_reruns``; escalate to manual remediation when limits are hit.
- **Audit trail:** Every engine invocation, fallback, manual edit, and queue message is timestamped.

## 7. Fallback Hierarchy
1. Unstructured parser (native PDFs/DOCX) + Tesseract OCR (images/scans).
2. EasyOCR/PaddleOCR for low-quality scans (log `fallback_attempts`).
3. Manual confirmation via gateway change queue (`pending_manual`).
4. Abort with `section_blocked` if mandatory fields remain unresolved.

## 8. Sectional Staging & Call-Out Procedures
- **Activation order:** Section 1 → Sections CP/DP/9 → Sections 2-8 → Section FR.
- **Trigger mechanisms:** `case_metadata_ready`, `subject_manifest_ready`, `contract_terms_ready` events.
- **Call-out:** Downstream sections issue `request_case_revision`; Section 1 reopens within revision limits, reapplies updates, reissues signals.

## 9. Information Handlers
- **Master case bundle:** Normalized metadata, evidence manifests, toolkit results, QA flags.
- **Evidence index:** Maps evidence IDs to artefacts; mirrored to durable storage after each mutation.
- **Toolkit snapshot:** Continuity checks, alias resolutions, QA notes.
- **Fact graph:** Shared entity/timeline graph aligning subjects, evidence IDs, and events; downstream sections query it for consistent identities.
- **Change queue:** Tracks manual confirmations or reruns required before final assembly.

## 10. Narrative & Template Blueprint
- Generate structured narrative (objective, scope, subjects, jurisdiction) from sanitized data.
- Templates are hash-locked and style-linted so unapproved phrasing is flagged; placeholders require reviewer acknowledgement.
- Store `dictated_narrative`, `approved_narrative`, diff metadata, and template hash.

## 11. Dissemination & Intelligence Sharing
- **Outbound feeds:** `case_summary`, `subject_manifest`, `contract_terms`, `risk_flags` broadcast to Sections CP, 2, 3, 5, 6, 7, 8.
- **Fact graph updates:** Subject and timeline nodes synchronized for all consuming sections.
- **Inbound feedback:** Downstream sections post discrepancy reports that reopen Section 1 under revision controls.
- **Cross-linking:** Evidence tags auto-link to Section 5 and FR manifests; persisted snapshots keep audit trail intact.

## 12. Operational & Unilateral Design Order
1. Gateway ingests case data, initializes async queue listeners, and locks environment.
2. Section 1 executes ingestion, normalization, validation, publishes `section_1_payload` to disk-backed store.
3. Gateway triggers dependent sections in priority order.
4. Monitoring loop enforces ``max_reruns``; manual queue handles exceptions.
5. Final assembly consumes immutable, signed payloads.

## 13. Implementation To-Do (Section 1)
- [ ] Integrate strongest-first extraction + fallback logic for all intake artefact types.
- [ ] Build master evidence index + cross-linking integrated with gateway and persisted to disk.
- [ ] Introduce async routing queues and separate persistence service so gateway restarts recover cleanly.
- [ ] Implement normalization pipeline driven by parsing maps/toolkit validations.
- [ ] Define `section_1_payload` schema (manifest, toolkit snapshot, QA flags, provenance, narrative, template hash).
- [ ] Update renderer to consume structured payload, enforce template/style lint, and log approvals.
- [ ] Enforce ``revision_depth`` / ``max_reruns`` caps and immutable sign-off workflows.
- [ ] Build shared fact graph service for cross-section identity/timeline alignment.
- [ ] Extend tests: extraction confidence, fallback path, manual queue, async queue recovery, persistence reload, fact graph queries, narrative style lint.
- [ ] Refresh README/SOP with final architecture and operational procedures.

